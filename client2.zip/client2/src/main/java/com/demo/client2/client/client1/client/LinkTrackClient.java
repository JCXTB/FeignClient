package com.demo.client2.client.client1.client;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

//@Component
//@FeignClient(name = "CLIENT1")
@RequestMapping("/link")
public interface LinkTrackClient {

    @PostMapping("/track")
    String linkTrack(String message);
}
