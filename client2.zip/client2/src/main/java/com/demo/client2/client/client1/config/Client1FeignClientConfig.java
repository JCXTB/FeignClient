package com.demo.client2.client.client1.config;

import com.demo.client2.client.client1.client.LinkTrackClient;
import com.demo.client2.client.client1.client.UserClient;
import feign.Client;
import feign.Contract;
import feign.Feign;
import feign.codec.Decoder;
import feign.codec.Encoder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.FeignClientsConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import(FeignClientsConfiguration.class)
public class Client1FeignClientConfig {

    private static final String CLIENT1_URL = "http://CLIENT1";

    @Autowired
    private Client feignClient;

    @Bean
    public UserClient Client1ClientFeignApi(Contract contract, Decoder decoder, Encoder encoder) {
        return Feign.builder().contract(contract).encoder(encoder).decoder(decoder).client(feignClient).target(UserClient.class, CLIENT1_URL);
    }

    @Bean
    public LinkTrackClient LinkTrackClientFeignApi(Contract contract, Decoder decoder, Encoder encoder) {
        return Feign.builder().contract(contract).encoder(encoder).decoder(decoder).client(feignClient).target(LinkTrackClient.class, CLIENT1_URL);
    }
}