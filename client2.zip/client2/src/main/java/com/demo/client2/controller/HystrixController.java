package com.demo.client2.controller;

import com.netflix.hystrix.contrib.javanica.annotation.DefaultProperties;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@DefaultProperties(defaultFallback = "defaultFallback")
public class HystrixController {
//    超时设置
//    @HystrixCommand(
//            commandProperties = {
//                    @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "5000")
//            }
//    )

//    熔断设置
//    @HystrixCommand(
//            commandProperties = {
//                    @HystrixProperty(name = "circuitBreaker.requestVolumeThreshold", value = "10"),     //断路器的最小请求数
//                    @HystrixProperty(name = "circuitBreaker.sleepWindowInMilliseconds", value = "10000"),   //休眠窗口
//                    @HystrixProperty(name = "circuitBreaker.errorThresholdPercentage", value = "60")        //错误百分比
//            }
//    )
    @HystrixCommand(commandKey = "hystrixGetMessage")     //配置项在配置文件中
    @GetMapping("/hystrixGetMessage")
    public String hystrixGetMessage(@RequestParam Integer message){
        if(message == 1){
            return "访问成功";
        }
        RestTemplate restTemplate = new RestTemplate();
        return restTemplate.postForObject("http://localhost:8081/hystrixGetMessage", "client2",String.class);

//        throw new RuntimeException("接口调用失败");
    }

    private String fallback(){
        return "太拥挤了，请稍候再试~~";
    }

    private String defaultFallback(){
        return "默认降级：太拥挤了，请稍候再试~~";
    }
}
