package com.demo.client2.controller;

import com.demo.client2.client.client1.client.LinkTrackClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/linkTrack")
public class LinkTrackController {
    @Autowired
    private LinkTrackClient linkTrackClient;

    @GetMapping("/getMessageByRestTemplate")
    public String getMessageByRestTemplate(){
        RestTemplate restTemplate = new RestTemplate();
        return restTemplate.postForObject("http://localhost:8081/link/track", "client2 请求 client1 接口", String.class);
    }

    @GetMapping("/getMessageByFeign")
    public String getMessageByFeign(){
        return linkTrackClient.linkTrack("client2 请求 client1 接口");
    }
}
