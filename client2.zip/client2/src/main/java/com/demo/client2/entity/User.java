/**
 * Project Name: client1
 * File Name: User
 * Package Name: com.demo.client1.entity
 * Date: 2019/7/10 13:25
 * Copyright (c) 2019, huafon Chuangxiang Co., Ltd. All Rights Reserved.
 */
package com.demo.client2.entity;

import lombok.Data;

@Data
public class User {
    private String name;

    private Integer age;
}
